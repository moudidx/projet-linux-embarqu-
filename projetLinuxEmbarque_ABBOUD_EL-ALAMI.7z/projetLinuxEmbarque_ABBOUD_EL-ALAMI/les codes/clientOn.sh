python /opt/domoticz/scripts/python/onAction.py

