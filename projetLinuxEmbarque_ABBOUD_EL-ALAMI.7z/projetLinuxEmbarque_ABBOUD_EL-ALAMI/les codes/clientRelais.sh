#!/bin/bash
gcc sysfsRelais.c -o sysfsRelaisExe
