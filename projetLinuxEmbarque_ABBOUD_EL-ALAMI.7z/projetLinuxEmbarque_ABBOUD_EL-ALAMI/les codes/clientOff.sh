python /opt/domoticz/scripts/python/offAction.py
