#!/bin/sh
echo 17 >/sys/class/gpio/export
echo out >/sys/class/gpio/gpio17/direction
echo 1 > value
echo 17 > /sys/class/gpio/unexport

